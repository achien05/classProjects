import java.util.ArrayList;
import java.util.LinkedList;
import java.lang.Thread;
import java.net.*;
import java.io.*;
public class ChatClient{
	public static final String BLACK = "\033[0;30m";   // BLACK
    public static final String RED = "\033[0;31m";     // RED
    public static final String GREEN = "\033[0;32m";   // GREEN
    public static final String YELLOW = "\033[0;33m";  // YELLOW
    public static final String BLUE = "\033[0;34m";    // BLUE
    public static final String PURPLE = "\033[0;35m";  // PURPLE
    public static final String CYAN = "\033[0;36m";    // CYAN
    public static final String WHITE = "\033[0;37m";   // WHITE
    public static final String ANSI_RESET = "\u001B[0m"; //Reset color

    public static void main(String[] args) throws IOException {
        if (args.length != 2) {
            System.err.println(
			       "Usage: java ChatClient <host name> <port number>");
            System.exit(1);
        }
 
        String hostName = args[0];
        int portNumber = Integer.parseInt(args[1]);
 
        try{
	    //Connect to the server by instantiating a Socket object: creates socket
        Socket clientSocket = new Socket(hostName, portNumber);

	    //Set the Socket output stream to a PrintWriter object: creates writer to write to output stream
        PrintWriter socketOut = new PrintWriter(clientSocket.getOutputStream(), true);
        //System.out.println(socketOut);

	    //Set the Socket input stream to a Buffered Reader: creates reader to read from input stream
        BufferedReader buffRead = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
        //System.out.println(buffRead);

	    //Read in username from terminal: creates reader to read from cmd line
        System.out.print("What will your username be?: ");
        BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in));
        //System.out.println(stdIn);
        String name = stdIn.readLine();
        if (name.equals("")) {
            System.out.println("Write a username with alphanumeric characters.");
            System.exit(1);            
        }
        //Send username string to server: actually writes username
		socketOut.println(name);
	    //Fire up a ClientReceiver thread
        ClientReceiver clientReceiver = new ClientReceiver(buffRead);
        clientReceiver.start();

        System.out.println(RED + "Welcome to the Chat\n You can now start chatting." + ANSI_RESET);
	    //Chatting below: 
	    String userInput;
	    while ((userInput = stdIn.readLine()) != null) {
            //System.out.println("here");
		socketOut.println(userInput);
            }
        } catch (Exception e) {
            System.err.println("ChatClient: " + e);
            System.exit(1);
        }
    }


}
