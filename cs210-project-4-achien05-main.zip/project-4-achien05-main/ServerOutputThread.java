import java.util.ArrayList;
import java.util.LinkedList;
import java.lang.Thread;
import java.net.*;
import java.io.*;
public class ServerOutputThread extends Thread{
	public static final String BLACK = "\033[0;30m";   // BLACK
    public static final String RED = "\033[0;31m";     // RED
    public static final String GREEN = "\033[0;32m";   // GREEN
    public static final String YELLOW = "\033[0;33m";  // YELLOW
    public static final String BLUE = "\033[0;34m";    // BLUE
    public static final String PURPLE = "\033[0;35m";  // PURPLE
    public static final String CYAN = "\033[0;36m";    // CYAN
    public static final String WHITE = "\033[0;37m";   // WHITE
    public static final String ANSI_RESET = "\u001B[0m"; //Reset color

    public void run(){
	try{
	    //Continually loop through all messages
		while(true){
			//If queue is not empty then pop message off the queue
			if(ChatServer.messages.size() != 0){
				String message = ChatServer.messages.remove(0);
				//Loop through all connections and send popped message to each connection
				for(Socket clientSocket : ChatServer.connections){
					PrintWriter serverOut = new PrintWriter(clientSocket.getOutputStream(), true);
					serverOut.println(message + "\n" + GREEN + "--------" + ANSI_RESET);
				}
			}
			else{
	   			//Sleep for 100 miliseconds if the queue is currently empty
				Thread.sleep(100);
			}
		}
	}
	catch(Exception e){
	    System.out.println("ServerOutputThread (run): " + e);
	}
    }
}
