import java.util.ArrayList;
import java.util.LinkedList;
import java.lang.Thread;
import java.net.*;
import java.io.*;
public class ChatServer{
    public static volatile ArrayList<Socket> connections = new ArrayList<>();
    public static volatile LinkedList<String> messages = new LinkedList<>();

    public static void main(String[] args){
	if (args.length != 1) {
            System.err.println(
			       "Usage: java ChatServer <server device public IP>");
            System.exit(1);
        }
	try{
	    //Fire up a ServerOutputThread
		ServerOutputThread serverOutThread = new ServerOutputThread();
		serverOutThread.start();
	    //Instantiate a ServerSocket in the below try parenthesis
	    try(ServerSocket serverSocket = new ServerSocket(0,0, InetAddress.getByName(args[0]))){
		//bind() the socket to null
		//serverSocket.bind(null);
		//print out the IP address using getInetAddress()
		System.out.println("Address: " + serverSocket.getInetAddress());
		//print out the ephemeral Port using getLocalPort()
		System.out.println("Port: " + serverSocket.getLocalPort());
		//construct a while loop to continually accept sockets
		while(true){
			ServerInputThread tmpServerInputThread = new ServerInputThread(serverSocket.accept());
			//System.out.println(tmpServerInputThread);synchr
			tmpServerInputThread.start();
			//tmpServerInputThread.join();
		}
	    }catch(Exception e){
		System.out.println("ChatServer: "+e);
	    }
	}catch(Exception e){
	    System.out.println("ChatServer: "+e);
	}	
    }

}
