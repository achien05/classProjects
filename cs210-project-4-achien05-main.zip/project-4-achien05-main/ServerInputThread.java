import java.util.ArrayList;
import java.util.LinkedList;
import java.lang.Thread;
import java.net.*;
import java.io.*;
public class ServerInputThread extends Thread{
	public static final String BLACK = "\033[0;30m";   // BLACK
    public static final String RED = "\033[0;31m";     // RED
    public static final String GREEN = "\033[0;32m";   // GREEN
    public static final String YELLOW = "\033[0;33m";  // YELLOW
    public static final String BLUE = "\033[0;34m";    // BLUE
    public static final String PURPLE = "\033[0;35m";  // PURPLE
    public static final String CYAN = "\033[0;36m";    // CYAN
    public static final String WHITE = "\033[0;37m";   // WHITE
    public static final String ANSI_RESET = "\u001B[0m"; //Reset color
	Socket clientSocket;
	String clientUserName;

    public void run(){
	try(BufferedReader buffRead = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()))){
	    //Read in a line representing the username
		//Set the username field
		String tmpStringUserName;
		if((tmpStringUserName = buffRead.readLine()) != null){
			//System.out.println(tmpStringUserName);
			clientUserName = tmpStringUserName;
			//System.out.println(clientUserName);
		}
	    //Add a new socket to the static connection list
		synchronized(ChatServer.connections){
			ChatServer.connections.add(clientSocket);
		}
	    //Continually read input from the client socket
	    //Add that input to the messages list with the username infront "JR: lorum ipsum"
		String tmpStringMessage;
		while((tmpStringMessage = buffRead.readLine()) != null){
			System.out.println(tmpStringMessage);
			synchronized(ChatServer.messages){
				ChatServer.messages.add(BLUE + clientUserName +": "+ WHITE + tmpStringMessage + ANSI_RESET);
			}
		}
	}catch(Exception e){
	    System.out.println("ServerInputThread (run): " + e);
	    System.exit(1);
	}
    }

    public ServerInputThread(Socket clientSocket){
	try{
	    //Set the appropriate fields 
		this.clientSocket = clientSocket;
	}catch(Exception e){
	    System.out.println("ServerInputThread (Constructor)"+e);
	    System.exit(1);
	}
    }
}
