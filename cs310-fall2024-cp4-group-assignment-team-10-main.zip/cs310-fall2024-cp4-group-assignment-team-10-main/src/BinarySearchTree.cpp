#include "BinarySearchTree.h"

BinarySearchTree::BinarySearchTree() {

}

BinarySearchTree::BinarySearchTree(const BinarySearchTree& other){
    root = other.getCopy(other.root, nullptr);
    num_elements = other.num_elements;
}

BinarySearchTree::~BinarySearchTree(){
    clearBST(root);
}

BinarySearchTree& BinarySearchTree::operator=(const BinarySearchTree& rhs){
	if(this == &rhs) return *this;
    this->clearBST(root);
    this->root = rhs.getCopy(rhs.root, nullptr);
    this->num_elements = rhs.num_elements;
    return *this;
}

Node* BinarySearchTree::getCopy(const Node* currNode, Node* parentNode) const {
    if(currNode == nullptr) return nullptr;
    Node* newNode = new Node(currNode->data);
    newNode->parent = parentNode;
    newNode->left = getCopy(currNode->left, newNode);
    newNode->right = getCopy(currNode->right, newNode);
    return newNode;
}

bool BinarySearchTree::insert(Voter& voterIn){
    if(root == nullptr){
        root = new Node(&voterIn);
        num_elements++;
        return true;
    }
    Node* currNode = root;
    while(currNode != nullptr){
        if(currNode->data->getFirst() == voterIn.getFirst() && currNode->data->getLast() == voterIn.getLast()){
            return false;
        }
        if(compareVoterByName(&voterIn, currNode->data)){
            if(currNode->left == nullptr){
                Node* tempNode = new Node(&voterIn);
                currNode->left = tempNode;
                tempNode->parent = currNode;
                num_elements++;
                return true;
            }else{
                currNode = currNode->left;
            }
        }else if(compareVoterByName(currNode->data, &voterIn)){
            if(currNode->right == nullptr){
                Node* tempNode = new Node(&voterIn);
                currNode->right = tempNode;
                tempNode->parent = currNode;
                num_elements++;
                return true;
            }else{
                currNode = currNode->right;
            }
        }else{  //if it got past first check...
            return false;
        }
    }
    return false;
}

Voter* BinarySearchTree::find(string lastName, string firstName){
    if(root == nullptr){
        return nullptr;
    }
    Node* currNode = root;
    while(currNode != nullptr){
        if(currNode->data->getLast() == lastName && currNode->data->getFirst() == firstName){
            return currNode->data;
        }else if(searchNameIsLess(lastName, firstName, currNode->data)){
            currNode = currNode->left;
        }else{
            currNode = currNode->right;
        }
    }
    return nullptr;
}

    void BinarySearchTree::clearBST(Node* currNode){
        num_elements = 0;
        if(currNode == nullptr){
            return;
        }
        clearBST(currNode->left);
        clearBST(currNode->right);
        delete currNode;
        currNode=nullptr;
    }
    
    bool BinarySearchTree::compareVoterByName(Voter* v1, Voter* v2){
        if(v1->getLast() == v2->getLast()){
            return (v1->getFirst() < v2->getFirst());
        }else{
            return (v1->getLast() < v2->getLast());
        }
    }

    bool BinarySearchTree::searchNameIsLess(string lastName, string firstName, Voter* voter){
        if(voter->getLast() == lastName){
            return firstName < voter->getFirst();
        }else{
            return lastName < voter->getLast();
        }
    }

    string BinarySearchTree::printOut(){
        string retrnString = "";
        return printNode(root, retrnString);
    }
    string BinarySearchTree::printNode(Node* currNode, string& rtnString){
        if(currNode == nullptr){
            rtnString += "";
            return rtnString;
        }
        printNode(currNode->left, rtnString);
        rtnString += currNode->data->getFirst() + " " + currNode->data->getLast() + ", " + std::to_string(currNode->data->getAge()) + " | ";
        printNode(currNode->right, rtnString);
        return rtnString;
    }