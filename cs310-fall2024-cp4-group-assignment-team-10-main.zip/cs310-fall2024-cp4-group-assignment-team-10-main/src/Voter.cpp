#include "Voter.h"

Voter::Voter(string firstName, string lastName, unsigned int voterAge, int voterSupport = 75, double voterLikelihood = 75.0, bool voted = false) {
	first = firstName;
	last = lastName;
	age = voterAge;
	support = voterSupport;
	likelihood = voterLikelihood;
	hasVoted = voted;
	heapIndex = 0;
}

Voter::Voter(string firstName, string lastName, unsigned int voterAge) {
	first = firstName;
	last = lastName;
	age = voterAge;
	support = 75;
	likelihood = 75.0;
	hasVoted = false;
	heapIndex = 0;
}

Voter::Voter() {
	first = "";
	last = "";
	age = 0;
	support = 0;
	likelihood = 0;	
	hasVoted = false;
	heapIndex = 0;
}

void Voter::show() {
	cout << last << ", " << first << ": " << age << endl;
}

string Voter::getFirst(){
	return first;
}
string Voter::getLast(){
	return last;
}
int Voter::getAge(){
	return age;
}
int Voter::getHeapIndex() {
	return heapIndex;
}
void Voter::modHeapIndex(int newIndex) {
	heapIndex = newIndex;
}
int Voter::getSupport(){
	return support;
}
void Voter::modSupport(int moddingInt){
	support += moddingInt;
}
double Voter::getLikelihood(){
	return likelihood;
}
void Voter::modLikelihood(int moddingInt){
	likelihood *= (100-moddingInt)/100.0;
}
double Voter::getImpact(){
	return (getSupport()/getLikelihood());
}
bool Voter::getHasVoted(){
	return hasVoted;
}
void Voter::modHasVoted(bool voted){
	hasVoted = voted;
}
// auto operator<=>(const Voter &other){

// }