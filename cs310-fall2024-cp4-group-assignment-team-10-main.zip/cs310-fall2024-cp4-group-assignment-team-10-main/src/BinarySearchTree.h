#include <iostream>
#include <stdlib.h>
#include "Node.h"
#include <string>
using namespace std;

#ifndef _H_BinarySearchTree
#define _H_BinarySearchTree

class BinarySearchTree{
  private:
    unsigned int num_elements = 0;
    Node* root = nullptr;
    void clearBST(Node* currNode);
    Node* getCopy(const Node* currNode, Node* parentNode) const;
    bool compareVoterByName(Voter* v1, Voter* v2);
    bool searchNameIsLess(string lastName, string firstName, Voter* voter);
  public:
    BinarySearchTree();
    BinarySearchTree(const BinarySearchTree& other);
    ~BinarySearchTree();
    BinarySearchTree& operator=(const BinarySearchTree& rhs);
    bool insert(Voter& voterIn);
    Voter* find(string lastName, string firstName);
    string printOut();
    string printNode(Node* currNode, string& rtnString);
};

#endif
