#include "System.h"
#include <string>
#include <sstream>
#include <iomanip>

string System::voter(string input[]) {
    unsigned int age = std::stoi(input[2]);
    if (age < 18 || age > 118) { return "Voter age should be between 18 and 118\n"; } // age between 18 and 118
    if (voterNames.find(input[0], input[1])) { return "Voter " + input[1] + " " + input[0] + ", age " + input[2] + ", already exists" + "\n"; }
    Voter* v = new Voter(input[1], input[0], age);
    votersAge[v->getAge() - 18].add_left(*v);
    voterImpact.insert(*v);
    voterNames.insert(*v);
    return "New voter " + get_name_age(*v) + ", added" + "\n";
}
string System::voted(string input[]) {
    Voter* v = voterNames.find(input[0], input[1]);
    if (!v) { return "Voter does not exist.\n"; }
    if (v->getHasVoted()) { return get_name(*v) + " already voted\n"; }
    v->modHasVoted(true);
    voterImpact.remove(*v);
    return "Voter " + get_name_age(*v) + ", voted" + "\n";
}
string System::support(string input[]) {
    unsigned int age = std::stoi(input[2]);
    Voter* v = voterNames.find(input[0], input[1]);
    if (!v) { return "Voter does not exist.\n"; }
    if(v->getHasVoted()){ return "Voter already voted.\n"; }
    v->modSupport(age);
    voterImpact.percolate_up(v->getHeapIndex());
    return "Support from " + get_name(*v) + " increased by " + input[2] + " strength points" + "\n";
}
string System::reduce_likelihood(string input[]) {
    unsigned int age = std::stoi(input[2]);
    Voter* v = voterNames.find(input[0], input[1]);
    if (!v) { return "Voter does not exist.\n"; }
    if(v->getHasVoted()){ return "Voter already voted.\n"; }
    v->modLikelihood(age);
    voterImpact.percolate_up(v->getHeapIndex());
    return "Voting likelihood of " + get_name(*v) + " decreased by " + input[2] + "%." + "\n";
}
string System::chauffeur(){               //if voted was called, this doesn't check that and may send some who voted
    Voter* max = voterImpact.extract_max();
    if(max == nullptr){
        return "Empty Queue.\n";
    }
    else{
        max->modHasVoted(true);
        stringstream ret;
        ret << "Driving " << max->getFirst() << " " << max->getLast() << " (" << max->getAge() << "): strength of support: " << max->getSupport() << ", likelihood: " << max->getLikelihood() << ", impact: " << fixed << setprecision(2) << max->getImpact() << defaultfloat << endl;
        return ret.str();
   }
}
string System::show_impact(){
    stringstream ret;
    for(int i = 0; i<100; i++){
        for(votersAge[i].restart();!votersAge[i].done();){
            Voter* v = votersAge[i].go_to_next();
            if(v->getHasVoted()){
                continue;
            }
            else{
                ret << get_name(*v) << " " << "(" << v->getAge() << "): strength of support: " << v->getSupport() << ", likelihood: " << v->getLikelihood() << ", impact: " << fixed << setprecision(2) << v->getImpact() << defaultfloat << endl;
            }
        }
    }
    return ret.str();
}

string System::get_name_age(Voter v) {
    return v.getFirst() + " " + v.getLast() + ", age " + std::to_string(v.getAge());
}

string System::get_name(Voter v) {
    return v.getFirst() + " " + v.getLast();
}

string System::printBST(){
  return voterNames.printOut();
}

string System::printHeap(){
  return voterImpact.printOut();
}
