#include "VoterLL.h"
VoterLL::VoterLL(){
}
VoterLL::VoterLL(const VoterLL &obj){
	VoterLLNode* currNode = head;
	if(obj.head != nullptr){
		for(VoterLLNode* otherCurrNode = obj.head; otherCurrNode != nullptr; otherCurrNode = otherCurrNode->next){
			if(head == nullptr){
				head = new VoterLLNode(otherCurrNode->data);
				currNode = head;
				continue;
			}
			currNode->next = new VoterLLNode(otherCurrNode->data);
			currNode->next->prev = currNode;
			currNode = currNode->next;
		}
	}
	iterPtr = head;
	num_elements = obj.num_elements;
}
VoterLL::~VoterLL(){
	makeEmpty();
}
VoterLL& VoterLL::operator=(const VoterLL& rhs){
	if(this ==  &rhs)return *this;
	VoterLLNode* currNode = head;
	if(rhs.head != nullptr){
		for(VoterLLNode* otherCurrNode = rhs.head; otherCurrNode != nullptr; otherCurrNode = otherCurrNode->next){
			if(head == nullptr){
				head = new VoterLLNode(otherCurrNode->data);
				currNode = head;
				continue;
			}
			currNode->next = new VoterLLNode(otherCurrNode->data);
			currNode->next->prev = currNode;
			currNode = currNode->next;
		}
	}
	this->iterPtr = head;
	this->num_elements = rhs.num_elements;
    return *this;
}
bool VoterLL::isEmpty(){
	return head==nullptr && num_elements == 0;
}
bool VoterLL::makeEmpty(){
	VoterLLNode* currNode = head;
	if(head == nullptr){			//0 nodes
		iterPtr = nullptr;
		return false;			//couldn't clear anything...
	}
	while(head != nullptr){
		head = head->next;
		removeNode(currNode);
		currNode = head;
	}
	iterPtr = nullptr;	
	num_elements = 0;
	return true;
}
void VoterLL::add_left(Voter& data){
	num_elements++;
	VoterLLNode* tempVoterLLNode = new VoterLLNode(&data);
	if(head == nullptr){
		head = tempVoterLLNode;
	}else{
		tempVoterLLNode->next = head;
		head->prev = tempVoterLLNode;
		head = tempVoterLLNode;
	}
}
void VoterLL::removeNode(VoterLLNode* fLLNode){
	if(fLLNode == nullptr){
		return;
	}
	if(fLLNode->prev == nullptr){
		head = fLLNode->next;
	}else{
		fLLNode->prev->next = fLLNode->next;
	}
	if(fLLNode->next != nullptr){
		fLLNode->next->prev = fLLNode->prev;
	}
	fLLNode->next = nullptr;
	fLLNode->prev = nullptr;
	num_elements--;
	delete fLLNode;
}
bool VoterLL::restart(){
	if(head != nullptr){
	iterPtr = head;
	return true;
	}	
	return false;	
}
bool VoterLL::done(){
	if(iterPtr == nullptr) return true;
	else return false;
}
Voter* VoterLL::go_to_next(){
	if(iterPtr != nullptr){
	    Voter* contents = iterPtr->data;
		iterPtr = iterPtr->next;
        return contents;	
	}
	return nullptr;
}

int VoterLL::get_num_elements() {
	return num_elements;
}
