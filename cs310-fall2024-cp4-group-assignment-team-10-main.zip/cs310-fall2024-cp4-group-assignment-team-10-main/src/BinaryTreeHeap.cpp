#include "BinaryTreeHeap.h"

void BinaryTreeHeap::swap_nodes_by_idx(int i1, int i2) {
    Voter * tmp = heapVector.at(i2);
    heapVector.at(i2) = heapVector.at(i1);
    heapVector.at(i1) = tmp;
    int tmpIdx = heapVector.at(i1)->getHeapIndex();
    heapVector.at(i1)->modHeapIndex(heapVector.at(i2)->getHeapIndex());
    heapVector.at(i2)->modHeapIndex(tmpIdx);
}

void BinaryTreeHeap::insert(Voter& in) {
    heapVector.push_back(&in);
    in.modHeapIndex(heapVector.size()-1);
    percolate_up(heapVector.size()-1);
}
Voter* BinaryTreeHeap::extract_max() {
    if(heapVector.size() <= 0){
        return nullptr;
    }
    if(heapVector.size() > 1){
        swap_nodes_by_idx(0,heapVector.size()-1);
    }
    Voter* voterPtr = heapVector.back();
    heapVector.pop_back();
    percolate_down(0);
    return voterPtr;
}
Voter& BinaryTreeHeap::peek_max() {
    return *heapVector.at(0);
}

void BinaryTreeHeap::percolate_up(int nodeIdx){
    if(nodeIdx == 0){
        return;
    }
    while(nodeIdx > 0) {
        if(heapVector.at(nodeIdx)->getImpact() > heapVector.at((nodeIdx - 1)/2)->getImpact()) {
            swap_nodes_by_idx(nodeIdx, (nodeIdx - 1)/2);
            nodeIdx = (nodeIdx - 1)/2;
        } else return;
    }    
}
void BinaryTreeHeap::percolate_down(int nodeIdx){
    int validIdx = (int)heapVector.size() - 1;
    if(nodeIdx > validIdx){
        return;
    }
    int parIdx = nodeIdx;
    float parent = heapVector.at(nodeIdx)->getImpact();
    int leftIdx = parIdx * 2 + 1;
    int rightIdx = parIdx * 2 + 2;
    float left = -1;
    float right = -1;
    while (parIdx <= validIdx) {
        if (leftIdx <= validIdx){
            left = heapVector.at(leftIdx)->getImpact();
        }
        if (rightIdx <= validIdx) {
            right = heapVector.at(rightIdx)->getImpact();
        }
        if (parent <= left || parent <= right) {
            if (left < right) {
                swap_nodes_by_idx(parIdx, rightIdx);
                parIdx = rightIdx;
            }
            else {
                swap_nodes_by_idx(parIdx, leftIdx);
                parIdx = leftIdx;
            }
        }
        else{
            break;
        }
        leftIdx = parIdx * 2 + 1;
        rightIdx = parIdx * 2 + 2;
        left = -1;
        right = -1;
    }
}

void BinaryTreeHeap::remove(Voter& v) {
    int index = v.getHeapIndex();
    if (index != heapVector.size() - 1) {
        swap_nodes_by_idx(index, heapVector.size() - 1);
        heapVector.pop_back();
        percolate_down(index);
        percolate_up(index);
    } else {
        heapVector.pop_back();
    }
}

string BinaryTreeHeap::printOut(){
    string retrnString = "";
    for(int i = 0; i < (int)heapVector.size(); i++){
        retrnString += heapVector.at(i)->getFirst() +" "+ heapVector.at(i)->getLast() +", "+ std::to_string(heapVector.at(i)->getSupport()) +", "+ std::to_string(heapVector.at(i)->getLikelihood()) +", "+ std::to_string(heapVector.at(i)->getImpact()) + " | ";
    }
    return retrnString;
}
