#include <iostream>
#include <stdlib.h>
#include <vector>
#include "Voter.h"
#include <string>
using namespace std;

#ifndef _H_BinaryTreeHeap
#define _H_BinaryTreeHeap

class BinaryTreeHeap{
  private:
    vector<Voter*> heapVector = vector<Voter*>();
    void swap_nodes_by_idx(int i1, int i2);
  public:
    // BinaryTreeHeap(const vector<Voter>& other);          //explicit value
    // ~BinaryTreeHeap();                        //destructor
    //BinaryTreeHeap operator=(const vector<Voter>& rhs);  //CAO
    void insert(Voter& in); //insert a voter object
    Voter* extract_max();
    Voter& peek_max();
    string printOut();
    void percolate_up(int nodeIdx);
    void percolate_down(int nodeIdx);
    void remove(Voter&);
};

#endif
