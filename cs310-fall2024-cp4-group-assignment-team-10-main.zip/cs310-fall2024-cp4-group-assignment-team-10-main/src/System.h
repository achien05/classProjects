#include "Voter.h"
#include <vector>
#include "BinaryTreeHeap.h"
#include "BinarySearchTree.h"
#include "VoterLL.h"

#ifndef _H_System_
#define _H_System_

class System{
	private:
		VoterLL votersAge[100];
		BinaryTreeHeap voterImpact;
		BinarySearchTree voterNames;
	public:
		string voter(string[]);
		string voted(string[]);
		string support(string[]);
		string reduce_likelihood(string[]);
		string chauffeur();
		string show_impact();
		string get_name_age(Voter);
		string get_name(Voter);
		string printBST();
		string printHeap();
};

#endif
