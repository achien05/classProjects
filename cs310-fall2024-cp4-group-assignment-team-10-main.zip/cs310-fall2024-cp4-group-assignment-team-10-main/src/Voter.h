#ifndef _H_Voter_
#define _H_Voter_

#include <iostream>
#include <stdlib.h>
#include <string>
using namespace std;

class Voter {
   private:
      string first = "";
      string last = "";
      unsigned int age = 0;
      int support = 0;
      double likelihood = 0;
      bool hasVoted = false;
      int heapIndex;

   public:
      Voter(string firstName, string lastName, unsigned int voterAge, int voterSupport, double voterLikelihood, bool voted);
      Voter(string firstName, string lastName, unsigned int voterAge);
      Voter();
      void show();
      string getFirst();
      string getLast();
      int getAge();

      int getHeapIndex();
      void modHeapIndex(int);

      int getSupport();
      void modSupport(int moddingInt);
      double getLikelihood();
      void modLikelihood(int moddingInt);
      double getImpact();
      
      bool getHasVoted();
      void modHasVoted(bool voted);
     // auto operator<=>(const Voter &other);
};

#endif
