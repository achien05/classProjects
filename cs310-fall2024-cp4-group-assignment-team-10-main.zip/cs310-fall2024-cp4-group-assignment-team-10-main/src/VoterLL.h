#ifndef _H_VoterLL
#define _H_VoterLL

#include <iostream>
#include <stdlib.h>
#include "Voter.h"
using namespace std;

class VoterLL{
   private:
	class VoterLLNode{
		public:
		VoterLLNode* next = nullptr;
		VoterLLNode* prev = nullptr;
		Voter* data;
		VoterLLNode(Voter* thing){
		data = thing;
		}
	};		
	VoterLLNode* head = nullptr;
	VoterLLNode* iterPtr = head;
	int num_elements = 0;
	void removeNode(VoterLLNode*);	
	
   public:
   	VoterLL();
   	VoterLL(const VoterLL &obj);
   	~VoterLL();
   	VoterLL& operator=(const VoterLL& rhs);
	bool isEmpty();
	bool makeEmpty();
	void add_left(Voter&);	
	bool restart();
	bool done();
	Voter* go_to_next();
	int get_num_elements();
};

#endif
