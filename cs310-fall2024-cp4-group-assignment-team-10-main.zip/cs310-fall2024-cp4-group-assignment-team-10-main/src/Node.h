#include <iostream>
#include <stdlib.h>
#include "Voter.h"
using namespace std;

#ifndef _H_Node
#define _H_Node

class Node{
  private:
  public:
    Node* parent = nullptr;
    Node* left = nullptr;
    Node* right = nullptr;
    Voter* data;                //used in all 3 data structures
    Node(Voter* contents){         
      data = contents;
    }
    ~Node(){
      delete data;
    }
};

#endif
