#include "System.h"
#include <string>
#include <iostream>
#include <map>
using namespace std;


map<string, int> ARG_SIZE = {
    {"quit", 0},
    {"voter", 3},
    {"voted", 3},
    {"support", 3},
    {"reduce-likelihood", 3},
    {"chauffeur", 0},
    {"show-impact", 0},
    {"printBST", 0},
    {"printHeap", 0}
};

int main(int argc, char const *argv[])
{
    System sys = System();
    string cmd;
    string args[4];

    bool run = true;
    while (run) {
        cin >> cmd;
        for (int i = 0; i < ARG_SIZE[cmd]; i++) {
            cin >> args[i];
        }
        if (cmd == "quit") run = false;
        else if (cmd == "voter") cout << sys.voter(args) << flush;
        else if (cmd == "voted") cout << sys.voted(args) << flush;
        else if (cmd == "support") cout << sys.support(args) << flush;
        else if (cmd == "reduce-likelihood") cout << sys.reduce_likelihood(args) << flush;
        else if (cmd == "chauffeur") cout << sys.chauffeur() << flush;
        else if (cmd == "show-impact") cout << sys.show_impact() << flush;
        else if (cmd == "printBST") cout << sys.printBST() << endl;
        else if (cmd == "printHeap") cout << sys.printHeap() << endl;
        else cout << "Invalid command." << endl << flush;
    }
    return 0;
}
