# cs310-fall2024-cp4-group-assignment

Full Names: Andrew Chien, Brendan Bulger, Abe Coburn

GitHub IDs: achien05, bbulger1, acoburn1

Binghamton CS userids: achien, bbulger1, acoburn1

Discord names: andy_cool05, bbulger22, acoburn1

Please type or copy the CS 310 honesty statement here:
I(We) have worked on this project individually (with only our group), and have not given or received too much help. In particular, I(we) have not gained access to any other students' repositories, files, or code, nor have i(we) given any other students access to mine(ours). I(We) have not used generative AI, including but not limited to chatGPT, unless explicitly authorized for this assignment. I(We) understand that my(our) code will be run through a very effective similarity checker, and that academic honesty violations are taken seriously.

With respect to the honesty statement, if you have any doubts whatsoever about whether you have completed the assignment appropriately, please describe briefly here:
