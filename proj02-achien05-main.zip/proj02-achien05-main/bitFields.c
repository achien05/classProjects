#include "bitFields.h"
#include <assert.h>

int getBit(int bn,unsigned long val) {
	assert(bn>=0 && bn<64);
	if (1UL<<bn & val) return 1;
	return 0;
}

void setBit(int bn,int new,unsigned long *val) {
	assert(bn>=0 && bn<64);
	if (new) (*val)|=1UL<<bn;
	else (*val)&=~(1L<<bn);
}

unsigned long getBitFldU(int bn,int len,unsigned long val) {
	// TODO:
	//		check to make sure bn is a valid bit position in long (you may assert this is true)
	//		check to make sure len is a valid length for a subfield that ends at bn (you may assert this is true)
	//  Here's one way to do this...
	// 		make a mask that has len 1's
	// 		Shift that mask left so it's rightmost 1 starts at bn
	//      Bitwise and the mask and val to isolate the bit field bits
	//		Shift the result to the right so that the rightmost bit of the bit field is bit 0
	//			Note that shift right pads to the left with the sign bit if the field is signed, but
	//			for unsigned, it will pad to the left with 0
	assert(len>0 && len<=64);
	assert(bn>=0 && (bn+len)<=64);
	unsigned long mask=((1L<<len)-1)<<bn;
	return (val&mask)>>bn; // Since val is unsigned, will pad right with 0's
	// return 0; // replace this with the correct code
}

long getBitFld(int bn,int len,unsigned long val) {
	// TODO:
	//		check to make sure bn is a valid bit position in long (you may assert this is true)
	//		check to make sure len is a valid length for a subfield that ends at bn (you may assert this is true)
	//	Here's one way to do this...
	//		Extract the bits for len ending at bn from val
	//      Shift the result to the right so the least significant bit is at position 0
	//		Sign extend by replacing all bits to the left of the most significant bit with the most significant bit
	//		Return the result.
	assert(len>0 && len<=64);
	assert(bn>=0 && (bn+len)<=64);
	unsigned long mask=((1L<<len)-1)<<bn;
	long result=(val&mask);
	// Shift so that leftmost requested bit moves to position 63
	result <<= (63-(bn+len-1));
	// Shift so that the (64-len) position becomes position 0
	result >>=(64-len);
	return result;
	// return 0; // replace this with the correct code
}

void setBitFld(int bn,int len,unsigned long new,unsigned long *val) {
	// TODO:
	//		check to make sure bn is a valid bit position in long (you may assert this is true)
	//		check to make sure len is a valid length for a subfield that ends at bn (you may assert this is true)
	//  Here's one way to do this...
	//      Make a mask that has len bits, right justified
	//		Bitwise AND new and the mask to turn off bits to the left of the field
	// 		Shift new and mask to the correct bit position
	//		Turn off all bits in *val under the mask by bitwise anding with ~mask
	//		Or *val with new.  (new has zeros for all non bit field positions, so won't affect val)
	unsigned long mask=(1L<<len)-1;
	new&=mask;
	new<<=bn;
	mask<<=bn;
	(*val)&=~mask;
	(*val)|=new;
}
