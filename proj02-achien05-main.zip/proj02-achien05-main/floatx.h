#ifndef FLOATX_H
#define FLOATX_H
typedef unsigned long floatx;

floatx doubleToFloatx(double val,int totBits,int expBits);
// double floatxToDouble(floatx val,int totBits,int expBits);

unsigned long getConcreteBits(double input);
int getSign(double floatIn);
int getUnbiasedExp(double floatIn);
int getBiasedExp(double floatIn);
unsigned long getFrac(double floatIn, int fracBits);

#endif
