#include "floatx.h"
#include <assert.h>
#include <math.h> // for isinf and isnan
#include <stdbool.h>
#include "bitFields.h" // For bit field library from hw03

#define DOUBLESIGNBIT 63
#define DOUBLEEXPSTART 62
#define DOUBLEEXPBITS 11
#define DOUBLEFRACSTART 51
#define DOUBLEFRACBITS 52
#define DOUBLEBIAS 1023

floatx doubleToFloatx(double val,int totBits,int expBits) {
	assert(totBits >= 3 && totBits <= 64);	//tot bits must be valid
	assert(expBits >= 1 && expBits <= 62);	//exp bits must be valid
	assert(expBits <= totBits-2);			//exp bits must be less than total bits with a sign and a frac bit minimum
	int fracBitNum = totBits-expBits-1;
	bool isInf = false;
	bool isNaN = false;
	bool isZero = false;
	bool isSubN = false;
	floatx ansFloatx = 0;
	setBit(totBits-1, getSign(val), &ansFloatx);						//sign set always
								
	long unbiasedExp = getUnbiasedExp(val);
	unsigned long bias = (1UL << (expBits-1))-1;							//identification stage
	unsigned long biasedExp = unbiasedExp + bias;
	//printf("%d ", unbiasedExp);
	//printf("%d ", biasedExp);
	//printf("%d ", bias);

	if(isinf(val)){	//was infinity OR shrank exponent bits, now infinity
		isInf = true;
		//printf("isInf ");
	}else if(val == +0.0 || val == -0.0){ //is +0.0 or -0.0
		isZero = true;
		//printf("is0.0 ");
	}else if(isnan(val)){	//identify Nan
		isNaN = true;
		//printf("isNaN ");
	}else if(unbiasedExp <= -((long)bias)+1){	//test for subnormal and underflow
		if(unbiasedExp < -(long)bias-fracBitNum+1){
			isZero = true;
			//printf("isUnd ");
		}else{
			isSubN = true;
			//printf("isSub ");
		}
	}else if((biasedExp) >= (1UL << (expBits))){	//test for overflow
		isInf = true;
		//printf("isOve ");
	}
	unsigned long frac;							//renormalize if was subnormal was a double
	if(!isInf && !isNaN && !isZero){
		if(unbiasedExp == -1022){
			frac = getFrac(val, 52);
			//printf("frac post: %x ", frac);
			for(int i = 51; i >= 0; i--){
				if(getBit(i, frac) == 1){
					//printf("%d ", 52-i);
					frac = frac << (52-i);
					biasedExp = biasedExp-(52-i);
					setBit(52, 0, &frac);
					break;
				}
			}
			if(fracBitNum < 52){
				frac = getBitFldU(52-fracBitNum, fracBitNum, frac);									//truncate to values needed
			}
		}
		else{
			frac = getFrac(val, fracBitNum);
		}
	}

	if(!isInf && !isNaN && !isZero && !isSubN){												//construction stage
		//printf("isNor ");
		//printf("frac post: %x ", frac);
		setBitFld(fracBitNum, expBits, biasedExp, &ansFloatx);
		if(fracBitNum > 52){
			setBitFld(fracBitNum-52, 52, frac, &ansFloatx);				//more than 52 bits needed insert to leftmost 52
		}else{
			setBitFld(0, fracBitNum, frac, &ansFloatx);					//should be pretruncated
		}
	}
	else{
		if(isZero){
			setBitFld(0, fracBitNum+expBits, 0UL, &ansFloatx);
		}
		if(isInf){
			setBitFld(0, fracBitNum, 0UL, &ansFloatx);
			setBitFld(fracBitNum, expBits, (1UL << (expBits))-1, &ansFloatx);
		}
		if(isNaN){
			setBitFld(fracBitNum, expBits, (1UL << (expBits))-1, &ansFloatx);
			setBit(fracBitNum-1, 1, &ansFloatx);
		}
		if(isSubN){
			setBitFld(fracBitNum, expBits, 0UL, &ansFloatx);		//should the frac contain:
			if(fracBitNum > DOUBLEFRACBITS){						//more than 52, frac should have 52 pad right with 0s
				setBit(DOUBLEFRACBITS, 1, &frac);
				frac = frac << (fracBitNum-52);
			}
			else if(fracBitNum == DOUBLEFRACBITS){					//exactly 52, frac should have 52
				setBit(DOUBLEFRACBITS, 1, &frac);
			}else{
				setBit(fracBitNum, 1, &frac);						//less than 52, frac should have been truncated from 52
			}
			frac = frac >> (-biasedExp + 1);
			setBitFld(0, fracBitNum, frac, &ansFloatx);
		}
	}
	return ansFloatx;

	// Make some assertions to ensure the totBits and expBits parameters are OK
	// Then, convert val to a floatx(totBits,expBits) result and return it.

	//return 0;  Remove this when you are done. re:No.
}

unsigned long getConcreteBits(double input) {
	union floatlong {
		double fl;
		unsigned long lng;
	} uf;
	uf.fl=input;
	return uf.lng;
}

int getSign(double floatIn) { 
	unsigned long concBits = getConcreteBits(floatIn);	
	int signVal = getBit(DOUBLESIGNBIT, concBits);
	// return the value of the sign bit from lng, 0 or 1
	return signVal; // Invalid value for now, nope
}

int getUnbiasedExp(double floatIn) {
	int biasedExpVal = getBiasedExp(floatIn);
	int unbiasedExpVal;
	if(biasedExpVal == 0){
		unbiasedExpVal = biasedExpVal - (DOUBLEBIAS-1);
	}else{
		unbiasedExpVal = biasedExpVal - DOUBLEBIAS;
	}
	//printf("%d", unbiasedExpVal);
	// return the value of the unbiased exponent in lng
	return unbiasedExpVal; // Invalid value for now, nope
}

int getBiasedExp(double floatIn) {
	unsigned long concBits = getConcreteBits(floatIn);	
	int biasedExpVal = (int)getBitFldU(DOUBLEFRACBITS, DOUBLEEXPBITS, concBits); 				//fracbits is 52, the same index as after the last frac bit.
	//printf("%d", (int)getBitFldU(DOUBLEFRACBITS, DOUBLEEXPBITS, concBits));
	// return the value of the biased exponent in lng
	return biasedExpVal; // Invalid value for now, nope
}

unsigned long getFrac(double floatIn, int fracBits) {int
	unsigned long concBits = getConcreteBits(floatIn);
	unsigned long fracVal;
	if(fracBits < 52){
		fracVal = getBitFldU(52-fracBits, fracBits, concBits);
	}else{
		fracVal = getBitFldU(0, 52, concBits);
	}
	return fracVal;
}


