#include "pool.h"
#include "pool_check.h"
#include <stdio.h>
#include <stdlib.h> // For malloc and free
#include <assert.h>

/*
	The implementation of the pool functions. See pool.h for external specs

*/

#define POOLSIZE 1000 // Number of bytes in the pool
void * pool_start=NULL; // The starting address of a pool
Reservation headReservation = NULL;
Reservation viewedReservation = NULL;
Reservation lSReservation = NULL; //left side of best gap in memory reserves

/*---------- Internal Function Declares ----------------*/
void * pool_get(int nbytes);
void pool_return(void * spacePtr);
Reservation createReservation(int numBytes, void* startAddress, Reservation nxt);
void deleteReservation(Reservation oldReservation);
void freeReservations(Reservation oldReservation);
/*---------- External Function Definitions ----------------*/
void pool_open() {
	assert(pool_start==NULL);
	pool_start=malloc(POOLSIZE);
	assert(pool_start!=NULL);
}

void * reserve(int nbytes) {
	assert(pool_start!=NULL);
	assert(nbytes > 0 && nbytes<POOLSIZE);					//max is 999, POOLSIZE = 1000;
	void * result=pool_get(nbytes);
	pool_check(result,nbytes);
	return result;
}

void unreserve(void * spacePtr) {
	assert(pool_start!=NULL);
	assert(spacePtr>=pool_start && spacePtr<(pool_start+POOLSIZE));
	pool_return(spacePtr);
	pool_check(spacePtr,0);
}

void pool_close() {
	assert(pool_start!=NULL);
	free(pool_start);
	freeReservations(headReservation);
	headReservation = NULL;
	viewedReservation = NULL;
	pool_start=NULL;
}

/*---------- Internal Function Definitions ----------------*/
void * pool_get(int nbytes) {													//performs like a schedule
	viewedReservation = headReservation;
	if(viewedReservation == NULL){												//blank reservation list scenario
		headReservation = createReservation(nbytes, pool_start, NULL);
		return headReservation->startAddr;
	}
	lSReservation = NULL;																							//no fitting gap: NULL and 0
	int bestGapSize = 0, gapSize;																					//gapSize,temp holder of a gap's size, eventually calculated at the end gap

	if((headReservation->startAddr != pool_start) && (headReservation->startAddr - pool_start >= nbytes)){			//if gap in front, check it to determine fit
		bestGapSize = headReservation->startAddr - pool_start;
	}

	while(viewedReservation->next != NULL){																			//check the other gaps for better fits, if one is found it becomes the leading contender
		gapSize = (viewedReservation->next->startAddr) - (viewedReservation->endAddr+1);
		if(gapSize >= nbytes && (bestGapSize < nbytes || gapSize < bestGapSize)){
			lSReservation = viewedReservation;
			bestGapSize = gapSize;
		}
		viewedReservation = viewedReservation->next;
	}

	gapSize = (pool_start+POOLSIZE) - (viewedReservation->endAddr+1);										//test after final reservation (may still have space there)
	if(gapSize >= nbytes && (bestGapSize < nbytes || gapSize < bestGapSize)){
		lSReservation = viewedReservation;
		bestGapSize = gapSize;
	}

	if(lSReservation == NULL && bestGapSize != 0){
		assert(pool_start+nbytes-1 < headReservation->startAddr);
		headReservation = createReservation(nbytes, pool_start, headReservation);
		return headReservation->startAddr;
	}
	if(lSReservation != NULL && bestGapSize != 0){
		if(lSReservation -> next == NULL){
			assert((lSReservation->endAddr+nbytes) < (pool_start+POOLSIZE));
		}
		else{
			assert((lSReservation->endAddr+nbytes) < (lSReservation->next->startAddr));
		}
		lSReservation->next = createReservation(nbytes, lSReservation->endAddr+1, lSReservation->next);
		return lSReservation->endAddr+1;
	}
	return NULL;
	/*																					
		This will find nbytes of space within the pool to reserve, and update any		
		book-keeping required to keep track of that space.								
	*/
}

void pool_return(void * spacePtr) {
	viewedReservation = headReservation;
	if(viewedReservation == NULL) return;
	if(viewedReservation->startAddr == spacePtr){
		headReservation = viewedReservation->next;
		deleteReservation(viewedReservation);
		return;
	}
	while(viewedReservation->next != NULL && viewedReservation->next->startAddr != spacePtr){
		viewedReservation=viewedReservation->next;
	}
	if(viewedReservation->next == NULL){	//not found
		return;
	}
	void * tempPointer = viewedReservation->next->next;
	free(viewedReservation->next);
	viewedReservation->next = tempPointer;

	/*
		This will return nbytes of space back to the pool by updating book-keeping
	*/
	return;
}
//option 2: page struct 10 bytes, each page contains starting address, binary reservationStatus
//pages stored in array (implement check if handed, respond accordingly) (return address of 1st page to allocate)
Reservation createReservation(int numBytes, void* startAddress, Reservation nxt){
	Reservation tempReservation = malloc(sizeof(struct reservation));
	tempReservation->startAddr = startAddress;
	tempReservation->endAddr = startAddress+numBytes-1;
	tempReservation->next = nxt;
	return tempReservation;
}

void deleteReservation(Reservation oldReservation){
	assert(oldReservation != NULL);
	free(oldReservation);
}

void freeReservations(Reservation oldReservation){
	assert(oldReservation != NULL);
	if(oldReservation->next != NULL){
		freeReservations(oldReservation->next);
	}
	oldReservation->next = NULL;
	free(oldReservation);
	
	return;
}