#include <stdio.h>
#include <stdlib.h>
#include "pool.h"

int main(int argc, char **argv) {

	// A test program to try out the memory pool
	int numTried=0;
	int numGood=0;
	int numRemoved=0;
	pool_open();
	char* mem[100];														//an array of pointers to memory addresses
	int value;

	printf("------ Starting pass 1\n");
	// Pass 1: allocate 10 spaces with varying sizes
	for(int i=1;i<=10;i++) {											//1*10=10, 2*10=20, 3*10=30, 4*10=40, etc... bytes reserved
		mem[i]=reserve(i*10);											//will call reserve and store returned, return is same as get()'s return
		numTried++;														//tick attempt count up by 1
		if (mem[i]!=NULL) numGood++;									//checks for good, if so tick good count by 1
		if (mem[i]!=NULL) {
			printf("Reserved %d bytes starting at %p\n",i*10,mem[i]);	//reports success
		} else {
			printf("Unable to reserve %d bytes... no room\n",i*10);		//reports failure
		}
	}
	for(int i=1;i<=10;i++) {											//for all of mem
		if (mem[i]!=NULL) {												//if reserved
			unreserve(mem[i]);
			numRemoved++;												//unreserve memory addresses from mem[i] to mem[i+1]-1
			printf("Unreserved %d bytes\n",i*10);						//print changes
		}
		mem[i]=NULL;													//after clear mem pool
	}																	//10+20+30+40+50+60+70+80+90+100=550, capacity capable, all can be 

	printf("\n------ Starting pass 2\n");
	// Pass 2: Allocate 10 more spaces, now with 50 byte sizes			//50+100+150+200+250+300+350+400+450+500=2750
	for(int i=1;i<=10;i++) {											//only 5 (50->250 will succeed)
		mem[i]=reserve(i*50);
		numTried++;
		if (mem[i]!=NULL) numGood++;
		if (mem[i]!=NULL) {
			printf("Reserved %d bytes starting at %p\n",i*50,mem[i]);
		} else {
			printf("Unable to reserve %d bytes... no room\n",i*50);
		}
	}
	for(int i=1;i<=10;i++) {
		if (mem[i]!=NULL) {
			unreserve(mem[i]);
			numRemoved++;
			printf("Unreserved %d bytes\n",i*50);
		}
		mem[i]=NULL;
	}

	printf("\n------ Starting pass 3\n");
	// Pass 3... same as pass 1, but twenty areas instead of 10			//Limit: 1 string per block(size of mem is 21)
	for(int i=1;i<=20;i++) {											//20 blocks, 10+20+30+40+50+60+70+80+90+100+110+120+130+140+150+160+170+180+190+200=2100
		mem[i]=reserve(i*10);											//1100 bytes unfufilled (10->130 will sucdeed)
		numTried++;
		if (mem[i]!=NULL) numGood++;
		if (mem[i]!=NULL) {
			printf("Reserved %d bytes starting at %p\n",i*10,mem[i]);
		} else {
			printf("Unable to reserve %d bytes... no room\n",i*10);
		}
	}
	for(int i=1;i<=10;i++) {											//only ten are unreserved (10,20,30,40,50,60,70,80,90,100)
		if (mem[i]!=NULL) {												//three blocks(110,120,130) remain reserved
			unreserve(mem[i]);
			numRemoved++;
			printf("Unreserved %d bytes\n",i*10);
		}
		mem[i]=NULL;
	}

	printf("\n------ Starting pass 4\n");
	// Pass 4 similar to pass 3 but does it with 2*i sized blocks
	for(int i=21;i<=36;i++) {											
		value = i*2;
		mem[i]=reserve(value);
		numTried++;
		if (mem[i]!=NULL) numGood++;
		if (mem[i]!=NULL) {
			printf("Reserved reservation %d of %d bytes starting at %p\n", i, value,mem[i]);
		} else {
			printf("Unable to reserve... no room\n");
		}
	}
	for(int i=21;i<=29;i++) {
		if (mem[i]!=NULL) {
			unreserve(mem[i]);
			numRemoved++;
			printf("Unreserved reservation %d\n",i);
		}
		mem[i]=NULL;
	}

	printf("\n------ Starting pass 5\n");
	// Pass 5 resumes pass 4 but with random numbers
	for(int i=37;i<=47;i++) {
		value = (rand()%200)+1;
		mem[i]=reserve(value);
		numTried++;
		if (mem[i]!=NULL) numGood++;
		if (mem[i]!=NULL) {
			printf("Reserved reservation %d of %d bytes starting at %p\n", i, value,mem[i]);
		} else {
			printf("Unable to reserve... no room\n");
		}
	}
	for(int i=37;i<=42;i++) {
		if (mem[i]!=NULL) {
			unreserve(mem[i]);
			numRemoved++;
			printf("Unreserved reservation %d\n",i);
		}
		mem[i]=NULL;
	}

	printf("\n------ Starting pass 6\n");
	// Pass 6 to test overlap (will increment the 2nd least significant hexadecimal digit)
	for(int i=48;i<=81;i++) {
		value = 16;						//manually set the value
		mem[i]=reserve(value);											
		numTried++;
		if (mem[i]!=NULL) numGood++;
		if (mem[i]!=NULL) {
			printf("Reserved reservation %d of %d bytes starting at %p\n", i, value,mem[i]);
		} else {
			printf("Unable to reserve... no room\n");
		}
	}
	for(int i=48;i<=69;i++) {
		if (mem[i]!=NULL) {
			unreserve(mem[i]);
			numRemoved++;
			printf("Unreserved reservation %d\n",i);
		}
		mem[i]=NULL;
	}
	pool_close();
	//pool_open();

	printf("\n__ Final Statistics, Tried %d reserves, %d successful, %d freed\n",numTried,numGood,numRemoved);

	return 0;
}
