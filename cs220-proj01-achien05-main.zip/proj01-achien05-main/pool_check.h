#ifndef POOL_CHECK_H

void pool_check(void * addStart,int nbytes);

#endif
#define POOL_CHECK_H
