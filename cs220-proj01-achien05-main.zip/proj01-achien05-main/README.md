# Project 1 - Allocation in a Memory Pool

## Project Description

For this project, you will complete a program that handles allocation of memory from a pool (very similar to malloc and free in C.)

Your job is to figure out how to allocate memory in a memory pool. The memory pool itself is provided for you. The memory pool is (arbitrarily) 1,000 bytes large. Users will ask to reserve portions of the memory pool by invoking a `reserve` function whose argument is the number of bytes to reserve. If you can find a block of that number of bytes in the memory pool, you should return the address of the beginning of that block. If no such block exists, you should return a NULL pointer.

For as long as the user has a block of memory reserved, she or he expects to have sole use of that memory. No other memory blocks in the pool can overlap reserved memory blocks.

At some later point, the users will return control of their reserved block  by invoking an `unreserve` function, passing back in the address of the block they originally reserved.

Your job is to figure out how to allocate memory blocks in the pool to try to achieve several (possibly conflicting) goals; namely:

- Satisfy as many reservation requests as possible.
- Efficiently return a reserve request.
- Efficiently satisfy an unreserve request.

## Memory Pool Infrastructure

You have been provided with the basic infrastructure for the C code to manage memory pools. The initial repository contains the following files:

- **tryPool.c** - An example of code from a user to invoke memory pool functions. This example opens a pool, makes 40 requests, and then closes the pool, reporting on how many of those requests were successful.

- **pool.h** - Declarations for all functions required by a pool user. These are very simple. `pool_open` creates a new memory pool, `reserve` reserves a block of memory in that pool, `unreserve` returns a block of memory to the pool, and `pool_close` is used when the user is done with the pool.

- **pool.c** - This is the *start* of the implementation of the memory pool code. Your job is to finish this code! Note that the four external functions are provided for you. There is an implementation of `pool_open`, `reserve`, `unreserve` and `pool_close` that already do pretty much all that's required. However, you may want to add to `pool_open` and `pool_close` to initialize and free up data structures.

    The `reserve` functions checks its arguments, and then invokes the internal function `pool_get`, which has *not* been implemented. Your main job is to implement the `pool_get` function is such a way that it returns the address of a block of memory in the pool if there is a block available; and keep track of that block so that future reserves don't get that (or part of that) block.

    And, the `unreserve` function also checks its arguments and then invokes the internal function `pool_return`. You will need to write the code for `pool_return` as well.

   Both `reserve` and `unreserve` also invoke the `pool_check` function. The `pool_check` function is intended to check to make sure that your allocation is correct. Note that the `pool_check` function is defined in file `pool_check.c`.

- **pool_check.h** - Contains a declaration of the `pool_check` function.

- **pool_check.c** - Contains the definition of the `pool_check` function. In this initial repository, this doesn't really check anything.

   You may want to code your own `pool_check` function to help debug your code. The two parameters are the address of a block of memory, and the size of that block. If the size is greater than zero, the `pool_check` function should assume that a reservation has just happened for that block. If the size is zero, the implication is that the block starting at that address is being **un**reserved.

   When your project is graded, the professor will substitute a correct definition of the `pool_check` function, and deduct points if your allocations do not follow the rules of a memory pool. Specifically, it will check to make sure that none of the memory allocations overlap each other within the pool.

- **Makefile** - A very simple Makefile that will compile all the code into a `tryPool` executable. There is a `test` target to run tryPool, a `gdb` target to run the tryPool under gdb, and a `clean` target to remove the tryPool executable file.

## Working the Project

If you download the proj01 repository and run `make`, you will find that there is already enough infrastructure to compile and run, but none of the user's reserve requests are honored.

You need to first think about how to keep track of user's reserve requests in such a way so that you can satisfy new reserve requests quickly, satisfy unreserve requests quickly, and satisfy as many reserve requests as possible.

The tryPool.c file is designed so that not all requests are satisfiable. In fact, about a quarter of the requests cannot be satisfied no matter what strategy you use. However, it will take some thinking to come up with an optimal strategy that is still efficient.

### Strategies to Think About

Do you want to keep track of the reserved areas in the pool? or the unreserved areas? Or both?

What kind of a data structure would work best to keep track of the blocks of memory? Try to choose a data structure that is relatively efficient in helping to solve the problems you are running into.

The biggest problem you have to deal with is memory fragmentation. See the Wikipedia article on [fragmentation](https://en.wikipedia.org/wiki/Fragmentation_(computing)) for more details. Will it help to occasionally clean up to reduce fragmentation? If so, what overhead does that introduce?

### Hints and Recommendations

1. Besides keeping track of the addresses of each block, you may also want to keep track of the length of the blocks in the pool.

2. Pay attention to the order in which you store block information. Do you want your order optimized for a reserve? an unreserve? A fragmentation clean-up?

3. Don't assume that the code in `tryPool.c` is the **only** way the pool functions will be called. The professor will run other unpublished examples of code which uses the pool functions to make sure your code works in all situations.

## Submitting your Results

Commit your updates to to the C files in the GitHub proj01-*gitUserName* repository, and post the resulting GitHub hash code in the submission space for Project 1 in Brightspace. You may submit multiple times, only the latest submission before the assignment deadline will be graded.

## Grading Criteria

This assignment is worth a total of 100 points. After the due date, your code will be loaded onto a Computer Science (LDAP) server, and compiled with the Professor's implementation of pool_check.c.

- Your code will be compared against all other CS-220 student submissions. If you wrote your own project code, it will be different enough from other students so that there will be no problem - even if you worked as a team on the concepts. If you cut and paste your code, or if your code is copied by someone else, even if you modify variable names, comments, white space, etc. it will be considered plagiarism, and result in a zero grade.

- There will be a 10-point deduction for each 24 hours your assignment is late up to a maximum of 5 days. (After 5 days, you will receive a zero.)

- If you do not try to address the problem in this project (in other words, if you turn in unmodified code), you will get a 100 point deduction.

- If your code has a compiler errors or logic errors, I will try to fix your code. For each simple fix, I will make that fix, subtract up to 20 points (depending on how bad the bug is), and continue testing. If there is no simple fix, or more than 3 compiler or logic errors, you will get a grade of 40 for this project.

- If your code fails any assertions when running tryPool, including assertions in the Professor's pool_check code, after any fixes I have made, you will get a 40 point deduction, and no further checks will be performed.

- The number of requests satisfied for tryPool will be compared against the optimal number achievable. Five points will be deducted for each request that could be satisfied by an optimal implementation, but is not satisfied by your implementation.

- Your code will be compiled with two other unpublished test cases (alternate versions of tryPool.c), and your results will be compared with the optimal results achievable. Two points will be deducted for each unsatisfied request that can be satisfied by an optimal implementation.

- Your code will be reviewed for efficiency in terms of both performance and memory usage. Up to 10 points may be deducted for clearly inefficient code.
