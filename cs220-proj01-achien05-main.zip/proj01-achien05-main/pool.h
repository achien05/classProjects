#ifndef POOL_H
/*
	External interface to a pool of memory

	pools are created/opened with pool_open, and deleted/removed with pool_close

	For an open pool, a user may reserve space within that pool that is nbytes large.
		0<nbytes<1000 (maximum pool size)
	The reserve function should return the address in memory of the start of the
		reserved space.
	If there is no block of nbytes unreserved space available, the reserve function
		should return a NULL pointer.
	The unreserve call should take as an argument the address of the reserved space,
		and remove the reservation of that space.
	Reserved spaces may not overlap with other reserved spaces.
	*/

struct reservation{
	void* startAddr;
	void* endAddr;
	struct reservation* next;	
};
typedef struct reservation* Reservation;

void pool_open();
void * reserve(int nbytes);
void unreserve(void * spacePtr);
void pool_close();

#define POOL_H
#endif
