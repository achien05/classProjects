#include "pool_check.h"
#include "assert.h"

char* checkedSpaces[1000];
void pool_check(void * addStart,int nbytes) {
	//if(nbytes == 0){
	//
	//}
	//for(int i = 0; i<)
	//assert(addStart+nbytes < );
	/*
		This is intended to check to make sure no reserved spaces within the pool overlap.
		If nbytes is zero, remove addStart from checked spaces.
		If there is overlap, an assert should fail.

		You may code your own implementation for debug, but when graded, the Professor
		will replace your implementation with a correct implementation.
	*/
}
